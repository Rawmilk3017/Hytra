import React, { useRef, useState } from "react";
import { motion } from "framer-motion";
import { styles } from "../styles";
import { EarthCanvas } from "./canvas";
import { SectionWrapper } from "../hoc";
import { slideIn } from "../utils/motion";
import { SOCIAL_LINKS } from "../constants";

const Contact = () => {
  const formRef = useRef();
  const [form, setForm] = useState({
    name: "",
    email: "",
    message: "",
  });

  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleChange = (e) => {
    const { target } = e;
    const { name, value } = target;

    setForm({
      ...form,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);

    if (!SOCIAL_LINKS.email) {
      // No contact email configured yet — add one in src/constants/index.js
      // (SOCIAL_LINKS.email) to enable this form.
      alert(
        "No contact email is configured yet. Reach out via GitHub in the meantime."
      );
      setLoading(false);
      return;
    }

    const mailtoLink = `mailto:${SOCIAL_LINKS.email}?subject=Message from ${encodeURIComponent(
      form.name
    )} (${encodeURIComponent(form.email)})&body=${encodeURIComponent(
      form.message
    )}`;

    window.location.href = mailtoLink;
    setLoading(false);
    alert("Thank you! Opening your email client to transmit the message.");

    setForm({
      name: "",
      email: "",
      message: "",
    });
  };

  const copyEmail = () => {
    navigator.clipboard.writeText(SOCIAL_LINKS.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className={`xl:mt-12 flex xl:flex-row flex-col-reverse gap-10 overflow-hidden`}
    >
      <motion.div
        variants={slideIn("left", "tween", 0.2, 1)}
        className="flex-[0.75] bg-black-100 p-8 rounded-2xl border border-[#232631]"
      >
        <p className={styles.sectionSubText}>Get in touch</p>
        <h3 className={styles.sectionHeadText}>Contact.</h3>

        <form
          ref={formRef}
          onSubmit={handleSubmit}
          className="mt-12 flex flex-col gap-8"
        >
          <label className="flex flex-col">
            <span className="text-white font-medium mb-4">Your Name</span>
            <input
              type="text"
              name="name"
              value={form.name}
              onChange={handleChange}
              placeholder="What's your name?"
              required
              className="bg-tertiary py-4 px-6 placeholder:text-secondary text-white rounded-lg outline-none border-none font-medium"
            />
          </label>
          <label className="flex flex-col">
            <span className="text-white font-medium mb-4">Your Email</span>
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="What's your email?"
              required
              className="bg-tertiary py-4 px-6 placeholder:text-secondary text-white rounded-lg outline-none border-none font-medium"
            />
          </label>
          <label className="flex flex-col">
            <span className="text-white font-medium mb-4">Your Message</span>
            <textarea
              rows={7}
              name="message"
              value={form.message}
              onChange={handleChange}
              placeholder="What do you want to say?"
              required
              className="bg-tertiary py-4 px-6 placeholder:text-secondary text-white rounded-lg outline-none border-none font-medium resize-none"
            />
          </label>

          <div className="flex flex-wrap items-center gap-4">
            <button
              type="submit"
              className="bg-tertiary py-3 px-8 rounded-xl outline-none w-fit text-white font-bold shadow-md shadow-primary border border-secondary/20 hover:border-[#915EFF] transition-colors"
            >
              {loading ? "Sending..." : "Send Message"}
            </button>

            {SOCIAL_LINKS.email && (
              <button
                type="button"
                onClick={copyEmail}
                className="bg-tertiary py-3 px-6 rounded-xl outline-none text-secondary hover:text-white font-medium border border-secondary/20 transition-colors"
              >
                {copied ? "Email Copied!" : "Copy Email"}
              </button>
            )}

            <a
              href={SOCIAL_LINKS.github}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-tertiary hover:border-[#915EFF] py-3 px-6 rounded-xl outline-none text-white font-medium border border-secondary/20 transition-colors"
            >
              GitHub
            </a>

            {SOCIAL_LINKS.discord && (
              <a
                href={SOCIAL_LINKS.discord}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#5865F2] hover:bg-[#4752C4] py-3 px-6 rounded-xl outline-none text-white font-medium transition-colors"
              >
                Discord
              </a>
            )}
          </div>
        </form>
      </motion.div>

      <motion.div
        variants={slideIn("right", "tween", 0.2, 1)}
        className="xl:flex-1 xl:h-auto md:h-[550px] h-[350px]"
      >
        <EarthCanvas />
      </motion.div>
    </div>
  );
};

export default SectionWrapper(Contact, "contact");
