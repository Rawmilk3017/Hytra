// NOTE: not currently wired into the live site — see src/constants/index.js for
// the SOCIAL_LINKS actually used by App.jsx's component tree.

export const SOCIAL_LINKS = {
  github: "https://github.com/Rawmilk3017",
  website: "https://rawmilk3017.net",
  discord: "",
  linkedin: "",
  instagram: "",
  twitter: "",
  youtube: "",
  email: ""
};

export const SOCIALS = [
  { name: "GitHub", url: SOCIAL_LINKS.github, available: true, label: "Rawmilk3017" },
  { name: "Website", url: SOCIAL_LINKS.website, available: true, label: "rawmilk3017.net" },
  { name: "Discord", url: SOCIAL_LINKS.discord, available: false, label: "" },
  { name: "LinkedIn", url: SOCIAL_LINKS.linkedin, available: false, label: "" },
  { name: "Instagram", url: SOCIAL_LINKS.instagram, available: false, label: "" },
  { name: "X / Twitter", url: SOCIAL_LINKS.twitter, available: false, label: "" },
  { name: "YouTube", url: SOCIAL_LINKS.youtube, available: false, label: "" }
];
