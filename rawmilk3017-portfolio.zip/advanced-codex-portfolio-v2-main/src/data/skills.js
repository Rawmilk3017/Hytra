// NOTE: not currently wired into the live site — see src/components/Tech.jsx
// and src/constants/index.js for the skills grid actually rendered by App.jsx.

export const SKILLS = [
  {
    id: "python",
    name: "Python",
    category: "Core Language",
    description: "General-purpose scripting, automation, and Discord bot development with Discord.py.",
    position: [-2.5, 1.2, 0.4],
    color: "#F5D0FE"
  },
  {
    id: "discordpy",
    name: "Discord.py",
    category: "Bot Engineering",
    description: "Slash commands, interaction handlers, moderation, tickets, and premium bot systems.",
    position: [-1.2, 2.2, -0.6],
    color: "#5865F2"
  },
  {
    id: "java",
    name: "Java",
    category: "Core Language",
    description: "Minecraft plugin development and custom gameplay systems.",
    position: [0.8, 2.4, 0.2],
    color: "#EC4899"
  },
  {
    id: "minecraft",
    name: "Minecraft / Paper",
    category: "Game Servers",
    description: "Paper server administration, plugin development, and custom gameplay systems.",
    position: [-2.2, -0.8, -0.4],
    color: "#5C8A3A"
  },
  {
    id: "worldedit",
    name: "WorldEdit",
    category: "Game Servers",
    description: "In-game world editing and terrain/structure tooling for Minecraft server projects.",
    position: [-0.6, -1.8, 0.5],
    color: "#8B5A2B"
  },
  {
    id: "javascript",
    name: "JavaScript",
    category: "Core Language",
    description: "Frontend scripting, HTML/CSS, and small web tools and dashboards.",
    position: [1.8, 1.4, -0.3],
    color: "#F5D0FE"
  },
  {
    id: "web-dashboards",
    name: "Web Dashboards",
    category: "Web Development",
    description: "Building dashboards and websites that connect to bots and Minecraft servers.",
    position: [2.4, -0.4, 0.3],
    color: "#A855F7"
  },
  {
    id: "ai-apis",
    name: "AI APIs (Groq)",
    category: "AI Integrations",
    description: "Wiring AI features and assistants into bots, dashboards, and server tools.",
    position: [1.2, -1.9, -0.5],
    color: "#F55036"
  },
  {
    id: "git",
    name: "Git / GitHub",
    category: "Tooling & DevOps",
    description: "Version control, project organization, and server/deployment automation.",
    position: [0.0, 0.2, 1.0],
    color: "#EC4899"
  }
];

// Graph connections for 3D constellation
export const SKILL_CONNECTIONS = [
  ["python", "discordpy"],
  ["python", "ai-apis"],
  ["java", "minecraft"],
  ["minecraft", "worldedit"],
  ["javascript", "web-dashboards"],
  ["discordpy", "web-dashboards"],
  ["python", "git"],
  ["java", "git"],
  ["web-dashboards", "git"],
  ["ai-apis", "web-dashboards"]
];
