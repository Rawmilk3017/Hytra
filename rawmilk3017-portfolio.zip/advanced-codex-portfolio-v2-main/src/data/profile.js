// NOTE: This file is not currently wired into the live site (see src/App.jsx,
// which renders the components in src/components/*.jsx using src/constants/index.js).
// It's kept here, personalized, in case this alternate component set gets used later.

export const PROFILE = {
  name: "Levi Marshall",
  handle: "Rawmilk3017",
  role: "Developer",
  titles: [
    "Discord Bot Developer",
    "Minecraft Developer",
    "Web Developer",
    "Automation & AI"
  ],
  heroHeading: "HEY, I'M LEVI.",
  heroStatement: "I BUILD DISCORD BOTS, MINECRAFT PROJECTS & WEB DASHBOARDS.",
  aboutHeading: "BUILDING AND LEARNING, ONE PROJECT AT A TIME.",
  aboutDescription:
    "I'm a developer who enjoys building things and experimenting with different technologies. My main areas are Discord development, Minecraft development, web development, automation, dashboards, and AI integrations.",
  contactHeading: "HAVE AN IDEA? LET'S BUILD IT.",
  contactDescription:
    "Have a project, collaboration or interesting idea? Reach out on GitHub.",
  location: "",
  status: "ONLINE // ACCEPTING NEW PROJECTS"
};
