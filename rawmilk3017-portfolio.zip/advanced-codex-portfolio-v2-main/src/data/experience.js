// NOTE: not currently wired into the live site — see src/constants/index.js
// (experiences) for the timeline actually rendered by App.jsx.

export const EXPERIENCES = [
  {
    id: "discord-bot-dev",
    category: "Discord Bot Development",
    focus: "Python & Discord.py",
    summary:
      "Building Discord bots with Python and Discord.py, from moderation and tickets to premium systems and dashboards.",
    highlights: [
      "Slash command systems and interactive components",
      "Permission-based moderation and ticket tooling",
      "Dashboards and APIs for bot configuration"
    ],
    tech: ["Python", "Discord.py", "APIs"],
    tag: "AUTOMATION & BOTS"
  },
  {
    id: "minecraft-dev",
    category: "Minecraft Development",
    focus: "Java, Paper & Plugins",
    summary:
      "Developing custom Minecraft plugins and gameplay systems in Java on Paper, along with server management.",
    highlights: [
      "Custom plugin and gameplay systems",
      "WorldEdit-based tooling",
      "Server setup and maintenance"
    ],
    tech: ["Java", "Paper", "WorldEdit"],
    tag: "GAME SERVERS"
  },
  {
    id: "web-dev",
    category: "Web & Dashboards",
    focus: "Sites, APIs & Panels",
    summary:
      "Building websites and dashboards that connect to bots and Minecraft projects.",
    highlights: [
      "Dashboards for bots and servers",
      "API integrations",
      "AI integrations using tools like Groq"
    ],
    tech: ["JavaScript", "APIs", "AI"],
    tag: "WEB & PLATFORMS"
  },
  {
    id: "automation-server-mgmt",
    category: "Automation & Server Management",
    focus: "Infrastructure & Tooling",
    summary:
      "Automating repetitive tasks and managing the servers behind bots, Minecraft instances, and web projects.",
    highlights: [
      "Deployment and task automation",
      "Server management for bots and game servers",
      "Ongoing learning of new tools as projects need them"
    ],
    tech: ["Automation", "Server Management"],
    tag: "INFRASTRUCTURE"
  }
];
