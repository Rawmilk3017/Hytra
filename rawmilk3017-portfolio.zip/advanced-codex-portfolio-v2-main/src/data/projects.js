// NOTE: not currently wired into the live site — see src/components/Works.jsx
// and src/constants/index.js for the projects grid actually rendered by App.jsx.

export const PROJECTS = [
  {
    id: "hytra",
    title: "Hytra",
    category: "Discord Bot",
    subtitle: "All-in-One Moderation, Tickets & Dashboard",
    description:
      "An all-in-one Discord bot project covering moderation, tickets, utilities, premium systems, a web dashboard, and automation.",
    tech: ["Python", "Discord.py", "Dashboard"],
    accentColor: "#A855F7",
    secondaryColor: "#5865F2",
    visualType: "dashboard",
    features: [
      "Moderation and ticket systems",
      "Premium feature tiers",
      "Web dashboard for configuration",
      "Automation utilities"
    ],
    github: "https://github.com/Rawmilk3017",
    discord: ""
  },
  {
    id: "deathbound-smp",
    title: "Deathbound SMP",
    category: "Minecraft SMP",
    subtitle: "Server, Website & AI Assistant Concept",
    description:
      "A Minecraft SMP project paired with its own website and an AI assistant concept for the server.",
    tech: ["Minecraft", "Paper", "AI"],
    accentColor: "#22C55E",
    secondaryColor: "#0EA5E9",
    visualType: "network",
    features: [
      "Custom SMP server",
      "Companion website",
      "AI assistant concept"
    ],
    github: "https://github.com/Rawmilk3017",
    discord: ""
  },
  {
    id: "minecraft-projects",
    title: "Minecraft Projects",
    category: "Minecraft Development",
    subtitle: "Plugins, Paper & Java",
    description:
      "Minecraft server and plugin work involving custom gameplay systems, Paper, Java, WorldEdit, and server management.",
    tech: ["Java", "Paper", "WorldEdit"],
    accentColor: "#8B5A2B",
    secondaryColor: "#5C8A3A",
    visualType: "matrix",
    features: [
      "Custom gameplay systems",
      "Paper plugin development",
      "Server management and setup"
    ],
    github: "https://github.com/Rawmilk3017",
    discord: ""
  },
  {
    id: "discord-bot-projects",
    title: "Discord Bot Projects",
    category: "Discord Bots",
    subtitle: "Tickets, Automation & APIs",
    description:
      "A collection of Discord bots built around tickets, moderation, automation, APIs, dashboards, and server management.",
    tech: ["Discord.py", "Automation", "APIs"],
    accentColor: "#F43F5E",
    secondaryColor: "#A855F7",
    visualType: "waveform",
    features: [
      "Ticket and moderation systems",
      "API integrations",
      "Dashboards and server management tooling"
    ],
    github: "https://github.com/Rawmilk3017",
    discord: ""
  }
];
