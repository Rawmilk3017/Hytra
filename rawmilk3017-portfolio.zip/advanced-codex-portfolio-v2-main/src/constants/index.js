import backend from "../assets/backend-eJbiv30d.png";
import creator from "../assets/creator-Kxn6XPAS.png";
import mobile from "../assets/mobile-nsCxKNJ2.png";
import web from "../assets/web-2Xs7v1YF.png";
import hytraImg from "../assets/projects/hytra.svg";
import deathboundImg from "../assets/projects/deathbound-smp.svg";
import minecraftProjectsImg from "../assets/projects/minecraft-projects.svg";
import discordBotProjectsImg from "../assets/projects/discord-bot-projects.svg";

export const navLinks = [
  {
    id: "about",
    title: "About",
  },
  {
    id: "work",
    title: "Experience",
  },
  {
    id: "skills",
    title: "Skills",
  },
  {
    id: "projects",
    title: "Projects",
  },
  {
    id: "contact",
    title: "Contact",
  },
];

export const services = [
  {
    title: "Discord Bot Developer",
    icon: mobile,
  },
  {
    title: "Minecraft Developer",
    icon: backend,
  },
  {
    title: "Web Developer",
    icon: web,
  },
  {
    title: "Automation & AI",
    icon: creator,
  },
];

export const technologies = [
  {
    name: "Python",
  },
  {
    name: "Java",
  },
  {
    name: "JavaScript",
  },
  {
    name: "HTML 5",
  },
  {
    name: "CSS 3",
  },
  {
    name: "Discord.py",
  },
  {
    name: "Discord.js",
  },
  {
    name: "Minecraft / Paper",
  },
  {
    name: "WorldEdit",
  },
  {
    name: "Groq AI",
  },
  {
    name: "Git / GitHub",
  },
];

export const experiences = [
  {
    title: "Discord Bot Development",
    company_name: "Python & Discord.py",
    icon: mobile,
    iconBg: "#383E56",
    date: "Primary Focus",
    points: [
      "Building Discord bots with Python and Discord.py, from moderation and tickets to premium systems.",
      "Designing slash command systems, interactive components, and permission-based utilities.",
      "Connecting bots to dashboards and APIs for configuration and live management.",
    ],
  },
  {
    title: "Minecraft Development",
    company_name: "Java, Paper & Plugins",
    icon: web,
    iconBg: "#E6DEDD",
    date: "Server & Plugin Systems",
    points: [
      "Developing custom Minecraft plugins in Java on Paper for SMP and gameplay servers.",
      "Building custom gameplay systems and server tooling using WorldEdit and related APIs.",
      "Managing and maintaining Minecraft server infrastructure.",
    ],
  },
  {
    title: "Web & Dashboards",
    company_name: "Sites, APIs & Panels",
    icon: creator,
    iconBg: "#383E56",
    date: "Full-Stack Projects",
    points: [
      "Building websites and web dashboards to go alongside bots and Minecraft projects.",
      "Working with APIs and automation to connect different parts of a project together.",
      "Experimenting with AI integrations, including tools built on Groq.",
    ],
  },
  {
    title: "Automation & Server Management",
    company_name: "Infrastructure & Tooling",
    icon: backend,
    iconBg: "#E6DEDD",
    date: "Ongoing",
    points: [
      "Automating repetitive tasks across Discord bots, Minecraft servers, and deployments.",
      "Managing servers that host bots, Minecraft instances, and web projects.",
      "Learning and experimenting with new tools as projects need them.",
    ],
  },
];

export const projects = [
  {
    name: "Hytra",
    description:
      "An all-in-one Discord bot project covering moderation, tickets, utilities, premium systems, a web dashboard, and automation.",
    tags: [
      {
        name: "discord.py",
        color: "blue-text-gradient",
      },
      {
        name: "python",
        color: "green-text-gradient",
      },
      {
        name: "dashboard",
        color: "pink-text-gradient",
      },
    ],
    image: hytraImg,
    source_code_link: "https://github.com/Rawmilk3017",
  },
  {
    name: "Deathbound SMP",
    description:
      "A Minecraft SMP project paired with its own website and an AI assistant concept for the server.",
    tags: [
      {
        name: "minecraft",
        color: "blue-text-gradient",
      },
      {
        name: "paper",
        color: "green-text-gradient",
      },
      {
        name: "ai",
        color: "pink-text-gradient",
      },
    ],
    image: deathboundImg,
    source_code_link: "https://github.com/Rawmilk3017",
  },
  {
    name: "Minecraft Projects",
    description:
      "Minecraft server and plugin work involving custom gameplay systems, Paper, Java, WorldEdit, and server management.",
    tags: [
      {
        name: "java",
        color: "blue-text-gradient",
      },
      {
        name: "paper",
        color: "green-text-gradient",
      },
      {
        name: "worldedit",
        color: "pink-text-gradient",
      },
    ],
    image: minecraftProjectsImg,
    source_code_link: "https://github.com/Rawmilk3017",
  },
  {
    name: "Discord Bot Projects",
    description:
      "A collection of Discord bots built around tickets, moderation, automation, APIs, dashboards, and server management.",
    tags: [
      {
        name: "discord.py",
        color: "blue-text-gradient",
      },
      {
        name: "automation",
        color: "green-text-gradient",
      },
      {
        name: "apis",
        color: "pink-text-gradient",
      },
    ],
    image: discordBotProjectsImg,
    source_code_link: "https://github.com/Rawmilk3017",
  },
];

export const SOCIAL_LINKS = {
  github: "https://github.com/Rawmilk3017",
  website: "https://rawmilk3017.net",
  // No public Discord invite or email provided yet — add here when ready.
  discord: "",
  email: "",
};
